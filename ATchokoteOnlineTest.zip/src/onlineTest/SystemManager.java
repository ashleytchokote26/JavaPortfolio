package onlineTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class SystemManager implements Manager, Serializable {

	private static final long serialVersionUID = 1L;
	protected Map<Integer, Exam> exams;
	protected Map<String, Student> students;
	protected String[] grades;
	protected double[] cutoffs;

	public SystemManager() {
		this.exams = new TreeMap<>();
		this.students = new TreeMap<>();
		this.grades = new String[] { "A", "B", "C", "D", "F" };
		this.cutoffs = new double[] { 90, 80, 70, 60, 0 };

	}

	@Override
	public boolean addExam(int examId, String title) {
		if (exams.containsKey(examId)) {
			return false;
		} else {
			exams.put(examId, new Exam(examId, title));
			return true;
		}
	}

	@Override
	public void addTrueFalseQuestion(int examId, int questionNumber, String text, double points, boolean answer) {
		exams.get(examId).deleteAndAddTFQuestion(examId, questionNumber, text, points, answer);
	}

	@Override
	public void addMultipleChoiceQuestion(int examId, int questionNumber, String text, double points, String[] answer) {
		exams.get(examId).deleteAndAddMCQuestion(examId, questionNumber, text, points, answer);
	}

	@Override
	public void addFillInTheBlanksQuestion(int examId, int questionNumber, String text, double points,
			String[] answer) {
		exams.get(examId).deleteAndAddFIBQuestion(examId, questionNumber, text, points, answer);
	}

	@Override
	public String getKey(int examId) {
		String str = "";
		if (exams.containsKey(examId)) {
			str += exams.get(examId).getKey(examId);
			return str;
		}
		str = "Exam not found";
		return str;
	}

	@Override
	public boolean addStudent(String name) {
		if (students.containsKey(name)) {
			return false;
		} else {
			students.put(name, new Student(name));
			return true;
		}
	}

	@Override
	public void answerTrueFalseQuestion(String studentName, int examId, int questionNumber, boolean answer) {
		Exam exam = exams.get(examId);
		for (int i = 0; i < exam.getExamLength(); i++) {
			if (i == questionNumber - 1) {
				Student student = students.get(studentName);
				student.checkExamId(examId);
				Question q = exam.questions.get(i);
				TrueFalseQuestion tfQ = (TrueFalseQuestion) q;
				if (tfQ.getAnswer() == answer) {
					student.addToScore(tfQ.getPoints());
					student.addToScoresList(tfQ.getPoints(), examId);
				} else if (tfQ.getAnswer() != answer) {
					student.addToScore(0.0);
					student.addToScoresList(0.0, examId);
				}
			}
		}
	}

	@Override
	public void answerMultipleChoiceQuestion(String studentName, int examId, int questionNumber, String[] answer) {
		Exam exam = exams.get(examId);
		for (int i = 0; i <= exam.getExamLength(); i++) {
			if (i == questionNumber - 1) {
				Student student = students.get(studentName);
				student.checkExamId(examId);
				Question q = exam.questions.get(i);
				MultipleChoiceQuestion MCQuestion = (MultipleChoiceQuestion) q;
				if (Arrays.toString(answer).equals(Arrays.toString(MCQuestion.getAnswer()))) {
					student.addToScore(MCQuestion.getPoints());
					student.addToScoresList(MCQuestion.getPoints(), examId);
				} else if (!Arrays.toString(answer).equals(Arrays.toString(MCQuestion.getAnswer()))) {
					student.addToScore(0.0);
					student.addToScoresList(0.0, examId);
				}
			}
		}

	}

	@Override
	public void answerFillInTheBlanksQuestion(String studentName, int examId, int questionNumber, String[] answer) {
		FillInBlankQuestion FIBQuestion = null;
		Student student = students.get(studentName);
		ArrayList<String> answersExam = new ArrayList<>();
		List<String> answersStudent = Arrays.asList(answer);
		double points = 0.0;
		double addScore = 0.0;
		Exam exam = exams.get(examId);
		int sizeFIB = 0;
		for (int i = 0; i < exam.getExamLength(); i++) {
			if (i == questionNumber - 1) {
				student.checkExamId(examId);
				Question q = exam.questions.get(i);
				FIBQuestion = (FillInBlankQuestion) q;
				sizeFIB += FIBQuestion.getAnswer().size();
				for (int j = 0; j < sizeFIB; j++) {
					answersExam.add(FIBQuestion.getAnswer().get(j));
				}
			}
		}
		points += FIBQuestion.getPoints() / sizeFIB;
		for (int i = 0; i < answersStudent.size(); i++) {
			if (answersExam.contains(answersStudent.get(i))) {
				addScore += points;
			}
		}
		student.addToScoresList(addScore, examId);
	}

	@Override
	public double getExamScore(String studentName, int examId) {
		double points = 0.0;
		Student s = students.get(studentName);
		for (Double d : s.getStuExamScores().get(examId)) {

			points += d;
		}
		return points;
	}

	@Override
	public String getGradingReport(String studentName, int examId) {
		String ans = "";
		Exam exam = exams.get(examId);
		Student s = students.get(studentName);
		double total = 0.0;
		for (int i = 0; i < exam.getExamLength(); i++) {
			Question q = exam.questions.get(i);
			total += q.getPoints();

			ans += "Question #" + q.getQuestionNumber() + " " + s.studentScores.get(examId).get(i) + " points out of "
					+ q.getPoints() + "\n";
		}
		ans += "Final Score: " + getExamScore(studentName, examId) + " " + "out of" + " " + total;
		return ans;
	}

	@Override
	public void setLetterGradesCutoffs(String[] letterGrades, double[] cutoffs) {
		letterGrades = this.grades;
		cutoffs = this.cutoffs;

	}

	@Override
	public double getCourseNumericGrade(String studentName) {
		double grades = 0.0;
		Student s = students.get(studentName);
		double examSize = s.getExams().size();
		for (int i = 0; i < examSize; i++) {
			int examId = s.getExams().get(i);
			Exam e = exams.get(examId);
			double examScore = getExamScore(studentName, examId);
			double totalScore = e.getTotalScore();
			grades += examScore / totalScore;

		}
		grades = (grades * 100) / examSize;
		return grades;
	}

	@Override
	public String getCourseLetterGrade(String studentName) {
		double grades = getCourseNumericGrade(studentName);
		for (int i = 0; i < cutoffs.length; i++) {
			if (cutoffs[i] <= grades) {
				return this.grades[i];
			}
		}
		return this.grades[this.grades.length - 1];
	}

	@Override
	public String getCourseGrades() {
		String answer = "";
		for (String s : students.keySet()) {
			answer += s + " " + getCourseNumericGrade(s) + " " + getCourseLetterGrade(s);
		}
		return answer;

	}

	@Override
	public double getMaxScore(int examId) {
		return Collections.max(getMaxAndMin(examId));

	}

	private ArrayList<Double> getMaxAndMin(int examId) {
		ArrayList<Double> list = new ArrayList<Double>();
		double studentScore = 0.0;
		System.out.print(students.keySet());
		for (String s : students.keySet()) {
			Exam exam = exams.get(examId);
			Student student = students.get(s);
			for (int i = 0; i < exam.getExamLength(); i++) {
				studentScore += student.studentScores.get(examId).get(i);
			}
			list.add(studentScore);
			studentScore = 0;
		}
		return list;
	}

	@Override
	public double getMinScore(int examId) {
		return Collections.min(getMaxAndMin(examId));
	}

	@Override
	public double getAverageScore(int examId) {
		ArrayList<Double> totalScores = getMaxAndMin(examId);
		double avg = 0.0;
		for (Double d : totalScores) {
			avg += d;

		}
		return avg / totalScores.size();
	}

	@Override
	public void saveManager(Manager manager, String fileName) {
		try {
			FileOutputStream file = new FileOutputStream(fileName);
			ObjectOutputStream outputStream = new ObjectOutputStream(file);
			outputStream.writeObject(manager);
			file.close();
			outputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public Manager restoreManager(String fileName) {
		Manager manager = null;
		try {
			FileInputStream file = new FileInputStream(fileName);
			ObjectInputStream objectInputStream = new ObjectInputStream(file);
			Manager manager1 = (Manager) objectInputStream.readObject();
			file.close();
			objectInputStream.close();
			manager = manager1;
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return manager;
	}

}
