package onlineTest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Student implements Serializable {

	private static final long serialVersionUID = 1L;
	private String studentName;
	private double score;
	protected Map<Integer, ArrayList<Double>> studentScores;
	ArrayList<Double> list;

	protected ArrayList<Integer> examIds;


	public Student(String studentName) {
		this.studentName = studentName;
		this.studentScores = new HashMap<>();
		this.examIds = new ArrayList<>();

	}

	public String getStudentName() {
		return studentName;
	}

	public double addToScore(double x) {
		return score += x;
	}

	public Map<Integer, ArrayList<Double>> getStuExamScores() {
		return studentScores;
	}

	public void checkExamId(int examId) {
		if (!examIds.contains(examId)) {
			examIds.add(examId);
			studentScores.put(examId, new ArrayList<Double>());
		}
	}

	public void addToScoresList(double score, int examId) {
		studentScores.get(examId).add(score);
	}

	public ArrayList<Integer> getExams() {
		return examIds;
	}

}
