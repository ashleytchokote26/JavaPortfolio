package onlineTest;

import java.io.Serializable;

public class Question implements Serializable{
	private static final long serialVersionUID = 1L;
	private String questionText;
	private int questionNumber;
	private double points;

	public Question(String questionText, int questionNumber, double points) {
		this.questionText = questionText;
		this.questionNumber = questionNumber;
		this.points = points;
	}

	public String getQuestionText() {
		return questionText;
	}

	public int getQuestionNumber() {
		return questionNumber;
	}

	public double getPoints() {
		return points;
	}
	
	public String toString() {
		String res = "Question Text: " +  getQuestionText() + "\n" + "Points: " 
	+ getPoints() + "\n";
		return res;
	}
}
