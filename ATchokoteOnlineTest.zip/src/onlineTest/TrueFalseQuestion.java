package onlineTest;

import java.io.Serializable;

public class TrueFalseQuestion extends Question implements Serializable{

	private static final long serialVersionUID = 1L;
	private String text;
	private int examId, questionNumber;
	private boolean answer, studentAnswer;
	private double points, totalScore;

	public TrueFalseQuestion(int examId, int questionNumber, String text, double points, boolean answer) {
		super(text, questionNumber, points);
		this.examId = examId;
		this.answer = answer;
		this.text = text;
		this.questionNumber = questionNumber;
		this.points = points;
	}

	public String getQuestionText() {
		return text;
	}

	public int getExamId() {
		return examId;
	}

	public int getQuestionNumber() {
		return questionNumber;
	}
 
	public double getPoints() {
		return points;
	}

	public boolean isCorrect() {
		return getAnswer() == setAnswer(answer)? true: false;
	}

	public boolean setAnswer(boolean answer) {
		return this.answer = answer;
	}

	public boolean getAnswer() {
		return answer;
	}

	public boolean getStudentAnswer() {
		return studentAnswer;
	}

	@Override
	public String toString() {
		String correctAnswer = getAnswer() ? "Correct Answer: True": "Correct Answer: False";
		String ans = super.toString() + correctAnswer + "\n";
 		return ans;
	}

}
