package onlineTest;

import java.io.Serializable;
import java.util.Arrays;

public class MultipleChoiceQuestion extends Question implements Serializable{
	private static final long serialVersionUID = 1L;
	private int examId, questionNumber;
	private String text;
	private double points;
	private String[] answer;

	public MultipleChoiceQuestion(int examId, int questionNumber, String text, double points, String[] answer) {
		super(text, questionNumber, points);
		this.examId = examId;
		this.questionNumber = questionNumber;
		this.text = text;
		this.points = points;
		this.answer = answer;
	}

	public int getExamId() {
		return examId;
	}

	public int questionNumber() {
		return questionNumber;
	}

	public String getQuestionText() {
		return text;
	}

	public double getPoints() {
		return points;
	}

	public String[] getAnswer() {
//		String ans = "";
//		for (int i = 0; i < answer.length; i++) {
//			ans += answer[i];
//		}
		return answer;
	}

	@Override
	public String toString() {
		return super.toString() + "Correct Answer: " + Arrays.toString(answer) + "\n";
	}

}
