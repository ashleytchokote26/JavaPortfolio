package onlineTest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Exam implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private int examId;
	private String title;
	protected ArrayList<Question> questions;
	protected double totalScore;

	public Exam(int examId, String title) {
		this.examId = examId;
		this.title = title;
		this.questions = new ArrayList<>();
		this.totalScore = 0.0;
	}

	public int getExamId() {
		return examId;
	}

	public String getTitle() {
		return title;
	}

	protected ArrayList<Question> getQuestions() {
		return questions;
	}

	protected double getTotalScore() {
		totalScore = 0.0;
		for(Question q: questions) {
			totalScore += q.getPoints();
		}
		return totalScore;
	}

	public int getExamLength() {
		return questions.size();
	}

	public void deleteAndAddTFQuestion(int examId, int questionNumber, String text, double points, boolean answer) {

		for (Question q : questions) {
			if (questionNumber == q.getQuestionNumber()) {
				questions.remove(q);
				questions.add(new TrueFalseQuestion(examId, questionNumber, text, points, answer));
				return;
			}
		}
		questions.add(new TrueFalseQuestion(examId, questionNumber, text, points, answer));
	}

	public void deleteAndAddMCQuestion(int examId, int questionNumber, String text, double points, String[] answer) {
		for (Question q : questions) {
			if (questionNumber == q.getQuestionNumber()) {
				questions.remove(q);
				Arrays.sort(answer);
				questions.add(new MultipleChoiceQuestion(examId, questionNumber, text, points, answer));
				return;
			}
		}
		Arrays.sort(answer);
		questions.add(new MultipleChoiceQuestion(examId, questionNumber, text, points, answer));
	}

	public void deleteAndAddFIBQuestion(int examId, int questionNumber, String text, double points, String[] answer) {
		for (Question q : questions) {
			if (questionNumber == q.getQuestionNumber()) {
				questions.remove(q);
				Arrays.sort(answer);
				questions.add(new FillInBlankQuestion(examId, questionNumber, text, points, answer));
				return;
			}
		}
		Arrays.sort(answer);
		questions.add(new FillInBlankQuestion(examId, questionNumber, text, points, answer));
	}

	public String getKey(int examId) {
		String answer = "";
		for (Question q : questions) {
			if (q instanceof TrueFalseQuestion) {
				TrueFalseQuestion tfQuestion = (TrueFalseQuestion) q;
				answer += tfQuestion.toString();
			} else if (q instanceof MultipleChoiceQuestion) {
				MultipleChoiceQuestion MCQuestion = (MultipleChoiceQuestion) q;
				answer += MCQuestion.toString();
			} else if (q instanceof FillInBlankQuestion) {
				FillInBlankQuestion FIBQuestion = (FillInBlankQuestion) q;
				answer += FIBQuestion.toString();
			}
		}
		return answer;
	}

}
