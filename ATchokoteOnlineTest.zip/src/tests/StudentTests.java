package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import onlineTest.Exam;
import onlineTest.FillInBlankQuestion;
import onlineTest.SystemManager;
import onlineTest.TrueFalseQuestion;
import onlineTest.Question;

/**
 * 
 * You need student tests if you are looking for help during office hours about
 * bugs in your code.
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void stu01AddExam() {
		SystemManager exams = new SystemManager();
		System.out.println(exams.toString());
		String title = "Midterm #1";
		int examId = 001;
		exams.addExam(examId, title);
		System.out.println(exams.toString());

	}

	@Test
	public void stu02AddTFQuestion() {
		TrueFalseQuestion tfQ = new TrueFalseQuestion(10, 1, "Abstract classes cannot have constructors.", 2, false);
		
		System.out.println("Exam Id: " + tfQ.getExamId());
		System.out.println("Question Number: " + tfQ.getQuestionNumber());
		System.out.println("Question Text: " + tfQ.getQuestionText());
		System.out.println("Points: " + tfQ.getPoints());
		System.out.println("Answer: " + tfQ.getAnswer());

	}
	
	@Test
	public void stud03Question() {
	Question q = new Question("Abstract classes cannot have constructors.", 2, 2.0);
	System.out.println("Question Text: " + q.getQuestionText());
	System.out.println("Question Number: " + q.getQuestionNumber());
	System.out.println("Points: " + q.getPoints());
	}
	
//	@Test
//	public void stu04Question() {
//		FillInBlankQuestion FIB = new FillInBlankQuestion(10, 1, "Name two types of initialization blocks.", 4.0, new String[]{"static","non-static"});
//		System.out.println("Answer: " + Arrays.toString(FIB.getAnswer()));
//	}

}
