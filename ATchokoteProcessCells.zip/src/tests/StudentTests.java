package tests;

import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.Game;
import model.ProcessCellGame;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	/* Remove the following test and add your tests */
	@Test
	public void student01GameGetters() {
		System.out.println("--------------Student Test 1--------------");
		Game game = new ProcessCellGame(8, 9, null, 1);
		int maxRows = game.getMaxRows();
		int maxCols = game.getMaxCols();
		System.out.println(maxRows);
		System.out.println(maxCols);
		assertEquals(maxRows, 8);
		assertEquals(maxCols, 9);
	}
}
