package model;

import java.util.Random;

/* Group Members
 * 1. Ayomiposi Ajayi - aajayi24
 * 2. Brandon Chen - bchen122
 * 3. Rebecca Queen - rqueen
 * Game Description: When a cell is clicked on, it will clear the cells of a different color 
 * in the horizontal, vertical, and diagonal directions. The score is a feature and multiplies.
 * The cell that is clicked on will not disappear.
 */

/**
 * This class extends GameModel and implements the logic of strategy #1. A
 * description of this strategy can be found in the javadoc for the processCell
 * method.
 * 
 * We define an empty cell as BoardCell.EMPTY. An empty row is defined as one
 * where every cell corresponds to BoardCell.EMPTY.
 * 
 * @author Department of Computer Science, UMCP
 */

public class ProcessCellGame extends Game {
	private int strategy;
	private Random random;
	private int score;
	private BoardCell[] emptyRow;

	/**
	 * Defines a board with empty cells. It relies on the super class constructor to
	 * define the board. The random parameter is used for the generation of random
	 * cells. The strategy parameter defines which processing cell strategy to use
	 * (for this project the default will be 1).
	 * 
	 * @param maxRows
	 * @param maxCols
	 * @param random
	 * @param strategy
	 */
	public ProcessCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols);
		this.strategy = strategy;
		this.random = random;
		score = 0;
		emptyRow = new BoardCell[maxCols];
		for (int col = 0; col < maxCols; col++) {
			emptyRow[col] = BoardCell.EMPTY;
		}
	}

	/**
	 * The game is over when the last board row (row with index board.length -1) is
	 * different from empty row.
	 */
	public boolean isGameOver() {
		boolean answer = true;
		if (strategy == 1 || strategy == 2) {
			for (int col = 0; col < getMaxCols(); col++) {
				if (board[board.length - 1][col] == BoardCell.EMPTY) {
					answer = false;
				}
			}
		} else {
			System.err.print("Invalid strategy");
			System.exit(1);

		}
		return answer;
	}

	public int getScore() {
		return score;
	}

	/**
	 * This method will attempt to insert a row of random BoardCell objects if the
	 * last board row (row with index board.length -1) corresponds to the empty row;
	 * otherwise no operation will take place.
	 */
	public void nextAnimationStep() {
		if (!isGameOver()) {
			for (int row = maxRows - 1; row > 0; row--) {
				board[row] = board[row - 1];
			}
			BoardCell[] answer = new BoardCell[board[0].length];

			for (int row = 0; row < board[0].length; row++) {
				answer[row] = BoardCell.getNonEmptyRandomBoardCell(random);
			}
			board[0] = answer;
		}
	}

	private boolean emptyRowCheck(int row) {
		for (int col = 0; col < board[row].length; col++) {
			if (board[row][col] != BoardCell.EMPTY) {
				return false;
			}
		}
		return true;
	}

	/**
	 * The default processing associated with this method is that for strategy #1.
	 * If you add a new strategy, make sure you add a conditional so the processing
	 * described below is associated with strategy #1. <br>
	 * <br>
	 * Strategy #1 Description.<br>
	 * <br>
	 * This method will turn to BoardCell.EMPTY the cell selected and any adjacent
	 * surrounding cells in the vertical, horizontal, and diagonal directions that
	 * have the same color. The clearing of adjacent cells will continue as long as
	 * cells have a color that corresponds to the selected cell. Notice that the
	 * clearing process does not clear every single cell that surrounds a cell
	 * selected (only those found in the vertical, horizontal or diagonal
	 * directions). <br>
	 * IMPORTANT: Clearing a cell adds one point to the game's score.<br>
	 * <br>
	 * 
	 * If after processing cells, any rows in the board are empty,those rows will
	 * collapse, moving non-empty rows upward. For example, if we have the following
	 * board (an * represents an empty cell):<br />
	 * <br />
	 * RRR<br />
	 * GGG<br />
	 * YYY<br />
	 * * * *<br/>
	 * <br />
	 * then processing each cell of the second row will generate the following
	 * board<br />
	 * <br />
	 * RRR<br />
	 * YYY<br />
	 * * * *<br/>
	 * * * *<br/>
	 * <br />
	 * IMPORTANT: If the game has ended no action will take place.
	 * 
	 * 
	 */

	public void processCell(int rowIndex, int colIndex) {
		if (board[rowIndex][colIndex] != BoardCell.EMPTY && board[rowIndex][colIndex] != null && !isGameOver()) {
			if (strategy == 1) {
				// 8 directions
				// vertical up(row index decreasing)
				for (int row = rowIndex - 1; row >= 0; row--) {
					if (board[rowIndex][colIndex] == board[row][colIndex]) {
						board[row][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// vertical down(row index increasing)
				for (int row = rowIndex + 1; row <= getMaxRows() - 1; row++) {
					if (board[rowIndex][colIndex] == board[row][colIndex]) {
						board[row][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// horizontal to the right
				for (int col = colIndex + 1; col <= getMaxCols() - 1; col++) {
					if (board[rowIndex][colIndex] == board[rowIndex][col]) {
						board[rowIndex][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// horizontal to the left
				for (int col = colIndex - 1; col >= 0; col--) {
					if (board[rowIndex][colIndex] == board[rowIndex][col]) {
						board[rowIndex][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to the top right
				for (int col = colIndex + 1, row = rowIndex - 1; col <= getMaxCols() - 1 && row >= 0; col++, row--) {
					if (board[rowIndex][colIndex] == board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to the top left
				for (int col = colIndex - 1, row = rowIndex - 1; col >= 0 && row >= 0; col--, row--) {
					if (board[rowIndex][colIndex] == board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to bottom right
				for (int row = rowIndex + 1, col = colIndex + 1; row <= getMaxRows() - 1
						&& col <= getMaxCols() - 1; col++, row++) {
					if (board[rowIndex][colIndex] == board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to bottom left
				for (int row = rowIndex + 1, col = colIndex - 1; row <= getMaxRows() - 1 && col >= 0; col--, row++) {
					if (board[rowIndex][colIndex] == board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				board[rowIndex][colIndex] = BoardCell.EMPTY;
				score++;

			}
			if (strategy == 2) {
				// 8 directions
				// vertical up(row index decreasing)
				for (int row = rowIndex - 1; row >= 0; row--) {
					if (board[rowIndex][colIndex] != board[row][colIndex]) {
						board[row][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// vertical down(row index increasing)
				for (int row = rowIndex + 1; row <= getMaxRows() - 1; row++) {
					if (board[rowIndex][colIndex] != board[row][colIndex]) {
						board[row][colIndex] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// horizontal to the right
				for (int col = colIndex + 1; col <= getMaxCols() - 1; col++) {
					if (board[rowIndex][colIndex] != board[rowIndex][col]) {
						board[rowIndex][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// horizontal to the left
				for (int col = colIndex - 1; col >= 0; col--) {
					if (board[rowIndex][colIndex] != board[rowIndex][col]) {
						board[rowIndex][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to the top right
				for (int col = colIndex + 1, row = rowIndex - 1; col <= getMaxCols() - 1 && row >= 0; col++, row--) {
					if (board[rowIndex][colIndex] != board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to the top left
				for (int col = colIndex - 1, row = rowIndex - 1; col >= 0 && row >= 0; col--, row--) {
					if (board[rowIndex][colIndex] != board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to bottom right
				for (int row = rowIndex + 1, col = colIndex + 1; row <= getMaxRows() - 1
						&& col <= getMaxCols() - 1; col++, row++) {
					if (board[rowIndex][colIndex] != board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}
				// diagonally to bottom left
				for (int row = rowIndex + 1, col = colIndex - 1; row <= getMaxRows() - 1 && col >= 0; col--, row++) {
					if (board[rowIndex][colIndex] != board[row][col]) {
						board[row][col] = BoardCell.EMPTY;
						score++;
					} else {
						break;
					}
				}

			}
			BoardCell[][] answer = new BoardCell[board.length][];
			int i = 0;
			for (int row = 0; row < board.length; row++) {
				if (emptyRowCheck(row) == false) {
					answer[i] = board[row];
					i++;
				}
			}
			for (int row = i; row < answer.length; row++) {
				answer[row] = emptyRow;
			}
			this.board = answer;

		}
	}
}