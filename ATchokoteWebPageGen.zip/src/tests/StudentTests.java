package tests;

import static org.junit.Assert.*;

import javax.swing.text.html.parser.Element;
import javax.swing.text.html.parser.TagElement;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.TextElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {


	@Test
	public void student01TextElementGenHTML() {
		System.out.println("----------Test01----------");		
		TextElement element = new TextElement("Ashley");
//		System.out.println(element.toString());
		String answer = element.genHTML(5);
		System.out.println(answer);
	}
	
	
	
	
}
