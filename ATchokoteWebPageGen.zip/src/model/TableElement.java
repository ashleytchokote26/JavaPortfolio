package model;

/**
 * Represents the &lt;table&gt tag. A two dimensional array is used to keep
 * track of the Element objects of table.
 * 
 * @author UMCP
 *
 */
public class TableElement extends TagElement {
	private Element[][] items;
	private int rows = 0;
	private int cols = 0;

	public TableElement(int rows, int cols, String attributes) {
		super("table", true, null, null);
		this.items = new Element[rows][cols];
		this.rows = rows;
		this.cols = cols;
		this.setAttributes(attributes);
	}

	public void addItem(int rowIndex, int colIndex, Element item) {
		items[rowIndex][colIndex] = item;
	}

	public double getTableUtilization() {
		double answer = 0;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {

				if (items[i][j] != null) {
					answer++;
				}
			}
		}
		answer = (answer / (rows * cols)) * 100;
		return answer;
	}

	public String genHTML(int indentation) {
		String answer = "";
		for (int i = 0; i < rows; i++) {
			answer = answer + "<tr>";
			for (int j = 0; j < cols; j++) {
				if (items[i][j] != null) {
					answer = answer + "<td>";
					answer += items[i][j].genHTML(0) + "</td>" + "\n";
				} else {
					answer = answer + "<td></td>";
				}
			}
			answer = answer + "</tr>";
		}
		return Utilities.spaces(indentation) + getStartTag() + "\n" + answer + "\n" + getEndTag();
	}
}
