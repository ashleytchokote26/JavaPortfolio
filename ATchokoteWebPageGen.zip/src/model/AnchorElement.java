package model;

/**
 * Represents the &lt;a&gt; tag.
 * @author UMCP
 *
 */
public class AnchorElement extends TagElement {
	private String linkText;
	private String url;
	
	public AnchorElement(String url, String linkText, String attributes) {
		super("a", true, null, (attributes != null)?" href=\"" + url + "\"" + attributes:" href=\"" + url + "\"");
		this.linkText = linkText;
		this.url = url;
	}
	
	public String getLinkText() {
		return linkText;
	}

	public String getURLText() {
		return url;
	}
	
	public String genHTML(int indentation) {
		
		return Utilities.spaces(indentation) + super.getStartTag() + linkText + super.getEndTag();
	}
}
