package model;

/**
 * 
 * Represents an HTML tag element (<&lt;p&gt;, &lt;ul&gt;, etc.). Each tag has
 * an id (ids start at 1). By default the start tag will have an id (e.g.,
 * <&lt;p id="a1"&gt;&lt;/p&gt;) when the HTML for the tag is generated. This
 * can be disabled by using enableId.
 * 
 * @author UMCP
 *
 */
public class TagElement implements Element {
	protected static int countId = 1;
	private int uniqueId = 0;
	private String stringId;
	protected String tagElement;
	private String startTag;
	private boolean endTag;
	private String attributes;
	private static boolean choice1;
	protected Element content;
	private static int levels = 0;
//	protected int paragraphId = 0;

	public TagElement(String tagElement, boolean endTag, Element content, String attributes) {
		this.content = content;
		this.tagElement = tagElement;
		this.endTag = endTag;
		this.attributes = attributes;
//		uniqueId++;
		uniqueId = countId;
		countId++;
	}

	public int getId() {
		return uniqueId;
	}

	public String getStringId() {
		stringId = tagElement + uniqueId;
		return stringId;
	}

	public String getStartTag() {

		if (choice1 == true && attributes != null) {
			return "<" + tagElement + " id=\"" + getStringId() + "\"" + " " + attributes + ">";
		}

		if (choice1 == true) {
			return "<" + tagElement + " id=\"" + getStringId() + "\"" + ">";
		}
		if (attributes != null) {
			return "<" + tagElement + " " + attributes + ">";
		}

		return "<" + tagElement + ">";
	}

	public String getEndTag() {
		if (endTag == true) {
			return "</" + tagElement + ">";
		} else {
			return "";
		}
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public static void resetIds() {
		countId = 1;
	}

	public static void enableId(boolean choice) {
		choice1 = choice;
	}

	@Override
	public String genHTML(int indentation) {
		if (content == null) {
			return Utilities.spaces(indentation) + getStartTag() + getEndTag();
		} else {
			return Utilities.spaces(indentation) + getStartTag() + this.content.genHTML(0) + getEndTag();
		}

	}

}