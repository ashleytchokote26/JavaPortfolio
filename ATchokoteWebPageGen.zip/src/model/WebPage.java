package model;

import java.util.*;

/**
 * Represents a web page. Web page elements are stored in an ArrayList of
 * Element objects. A title is associated with every page. This class implements
 * the Comparable interface. Pages will be compared based on the title.
 * 
 * @author UMCP
 *
 */
public class WebPage implements Comparable<WebPage> {
	private ArrayList<Element> elements;
	private String title;
	private static boolean choices;

	public WebPage(String title) {
		this.title = title;
		elements = new ArrayList<>();
	}

	public int addElement(Element element) {
		elements.add(element);
		if (element instanceof TagElement) {
			return ((TagElement) element).getId();
		} else {
			return -1;
		}

	}

	public String getWebPageHTML(int indentation) {
		String answer = "";

		for (Element e : elements) {
			answer = answer + e.genHTML(0);
		}

		return "<!doctype html>\r\n" + "<html>\r\n" + "   <head>" + " <meta charset=\"utf-8\"/>\r\n" + "      <title> "
				+ title + "\n" + "</title>" + "\n" + "</head>\r\n" + "   <body>\r\n" + answer + "   </body>\r\n"
				+ "</html>";
	}

	public void writeToFile(String filename, int indentation) {
		Utilities.writeToFile(filename, "   ");
	}

	public Element findElem(int id) {
		for (Element e : elements) {
			if (((TagElement) e).getId() == id) {
				return e;
			}
		}
		return null;
	}

	public String stats() {
		String answer = "";
		int listCount = 0;
		int paragraphCount = 0;
		int tableCount = 0;
		double tableUtil = 0;

		for (Element e : elements) {
			if (e instanceof ListElement) {
				listCount++;
			}
			if (e instanceof ParagraphElement) {
				paragraphCount++;
			}
			if (e instanceof TableElement) {
				tableUtil += ((TableElement) e).getTableUtilization();
				tableCount++;
			}
			
		}
		answer += "List Count: " + listCount;
		answer += "Paragraph Count: " + paragraphCount;
		answer += "Table Count: " + tableCount;
		answer += "TableElement Utilization: " + (tableUtil)/tableCount;
		return answer;
	}

	@Override
	public int compareTo(WebPage o) {
		return title.compareTo(o.title);

	}

	public static void enableId(boolean choice) {
		choices = choice;
	}

}
