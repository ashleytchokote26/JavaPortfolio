package model;

import java.util.ArrayList;

/**
 * Represents the &lt;ul&gt and the &lt;ol&gt; tags. An ArrayList is used to
 * keep track of the Element objects of the list.
 * 
 * @author UMCP
 *
 */
public class ListElement extends TagElement {
	private ArrayList<Element> items;


	public ListElement(boolean ordered, String attributes) {
		super("ul", true, null, attributes);
		this.items = new ArrayList<>();
		if(ordered == true) {
			tagElement = "ol";
		}
		else {
			tagElement = "ul";
		}
	}

	public void addItem(Element item) {
		items.add(item);
	}

	public String genHTML(int indentation) {
		String answer = "";
		Utilities.defaultSpaces(3);
		for (int i = 0; i < items.size(); i++) {

			answer = answer +  "<li>" + "\n" + items.get(i).genHTML(indentation) + "\n"
					+ "</li>" ;
			
		}
		return Utilities.spaces(indentation) + getStartTag() + Utilities.spaces(indentation) + "\n" + answer + "\n"
				+ getEndTag();
	}
}
