package processor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Order implements Runnable {

	protected TreeMap<String, Double> itemsPrices;
	protected File filenameRef;
	protected TreeMap<String, Integer> itemsAndQuantity;

	public Order(TreeMap<String, Double> itemsPrices, String filename) {
		this.itemsPrices = itemsPrices;
		this.filenameRef = new File(filename);
		itemsAndQuantity = new TreeMap<String, Integer>();

	}

	public synchronized double getTotal() {
		double answer = 0.0;
		for (Map.Entry<String, Integer> e : itemsAndQuantity.entrySet()) {
			double quantity = itemsAndQuantity.get(e.getKey()).doubleValue();
			double price = itemsPrices.get(e.getKey());
			answer += quantity * price;
		}
		return answer;
	}

	public Map<String, Integer> getItemsAndQuantity() {
		return itemsAndQuantity;
	}

	public Map<String, Double> getPrices() {
		return itemsPrices;
	}

	@Override
	public synchronized void run() {
		try {
			Scanner fileScanner = new Scanner(filenameRef);
			fileScanner.next();
			int clientId = fileScanner.nextInt();
			System.out.println("Reading order for client with id: " + clientId);
			while (fileScanner.hasNextLine()) {
				String item = fileScanner.next();
				fileScanner.next();
				if (itemsAndQuantity.containsKey(item)) {
					itemsAndQuantity.put(item, itemsAndQuantity.get(item) + 1);
				} else {
					itemsAndQuantity.put(item, 1);

				}
			}
			fileScanner.close();

		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		}

	}

	public String toString() {
		String answer = "";
//		answer += "----- Order details for client with Id:  -----" + "\n";
		for (Map.Entry<String, Integer> e : getItemsAndQuantity().entrySet()) {
//			if (e.getValue() > 0) {
//				System.out.println(itemsPrices.get(e.getKey()));
				answer += "Item's name: " + e.getKey() + ", " + "Cost per item: " + NumberFormat.getCurrencyInstance().format(getPrices().get(e.getKey())) + "," + " Quantity: "
						+ e.getValue() + ", Cost: " + NumberFormat.getCurrencyInstance().format(e.getValue() * getPrices().get(e.getKey())) + "\n";
			}
//		}
		answer += "Order Total: " + NumberFormat.getCurrencyInstance().format(getTotal()) + "\n";
		return answer;

	}

	// get the product
	public Integer get(String i) {
		if (itemsAndQuantity.containsKey(i)) {
			return itemsAndQuantity.get(i);
		}
		return 0;
	}

}
