package processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class OrdersProcessor {
	public synchronized static void main(String args[]) {
		TreeMap<Integer, Order> client = new TreeMap<Integer, Order>();
		TreeMap<String, Double> itemPrices = new TreeMap<String, Double>();

		Scanner s = new Scanner(System.in);

		System.out.println("Enter item's data file name: ");
		String filename = s.nextLine();

		try {
			FileReader fileReader = new FileReader(filename);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			Scanner scanner = new Scanner(bufferedReader);
			while (scanner.hasNextLine()) {
				String answer = scanner.next();
//				System.out.println("this is the item" + answer);
//				System.out.println(scanner.nextDouble());

				Double prices = scanner.nextDouble();

				itemPrices.put(answer, prices);
			}
//			System.out.println("this is items" + itemPrices + "done with");

			scanner.close();
//			fileReader.close();
//			bufferedReader.close();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

		System.out.println("Enter 'y' for multiple threads, any other character otherwise:");
		String multThreadsAns = s.nextLine();
		boolean multThreadsAnsRes = multThreadsAns.equalsIgnoreCase("y") ? true : false;

		System.out.println("Enter number of orders to process: ");
		int numOfOrders = s.nextInt();

		System.out.println("Enter order's base filename: ");
		String baseFilename = s.next();

		System.out.println("Enter result's filename: ");
		String resFile = s.next();

		long startTime = System.currentTimeMillis();
		s.close();
		/* TASK YOU WANT TO TIME */

		if (!multThreadsAnsRes) {

			for (int i = 1; i <= numOfOrders; i++) {
				try {
					Scanner scanner = new Scanner(new File(baseFilename + Integer.toString(i) + ".txt"));
					scanner.next();
					Order o = new Order(itemPrices, baseFilename + Integer.toString(i) + ".txt");
					o.run();
					client.put(scanner.nextInt(), o);
					scanner.close();
				} catch (FileNotFoundException e) {
					System.err.println(e.getMessage());
				}
			}
		} else if (multThreadsAnsRes) {
			Thread[] threads = new Thread[numOfOrders];

			for (int i = 1; i <= numOfOrders; i++) {
				try {
					Scanner scanner = new Scanner(new File(baseFilename + Integer.toString(i) + ".txt"));
					scanner.next();
					Order o = new Order(itemPrices, baseFilename + Integer.toString(i) + ".txt");
					Thread thread = new Thread(o);
					threads[i - 1] = thread;

					thread.start();
					client.put(scanner.nextInt(), o);
					scanner.close();

				} catch (FileNotFoundException e) {
					System.err.println(e.getMessage());
				}
			}
		}
		fileWriter(resFile, client, itemPrices);
		long endTime = System.currentTimeMillis();
		System.out.println("Processing time (msec): " + (endTime - startTime));
		System.out.println("Results can be found at: " + filename);

	}

	private synchronized static void fileWriter(String filename, TreeMap<Integer, Order> orders,
			TreeMap<String, Double> itemsPrices) {
//		boolean append = false;
		try {
			FileWriter fileWriter = new FileWriter(filename);
			for (Map.Entry<Integer, Order> e : orders.entrySet()) {
//				fileWriter.write("start: ");
				fileWriter.write("----- Order details for client with Id: " + e.getKey() + " -----\r\n");
				fileWriter.write(e.getValue().toString());
			}
			fileWriter.write("***** Summary of all orders *****\r\n");

			double total = 0.0;
			for (String i : itemsPrices.keySet()) {
				int numOfItems = 0;
				for (Integer o : orders.keySet()) {
					numOfItems += orders.get(o).get(i);
				}
//				if (numOfItems > 0) {
					fileWriter.write("Summary - Item's name: " + i + ", " + "Cost per item: "
							+ NumberFormat.getCurrencyInstance().format(itemsPrices.get(i)) + "," + "Number sold: "
							+ numOfItems + "," + "Item's Total: "
							+ NumberFormat.getCurrencyInstance().format(numOfItems * itemsPrices.get(i)) + "\n");
					total += (numOfItems * itemsPrices.get(i));

//				}

			}
			fileWriter.write("Summary Grand Total: " + NumberFormat.getCurrencyInstance().format(total) + "\n");
			fileWriter.close();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

	}
}