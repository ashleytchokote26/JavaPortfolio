package system;

public class CombineLeftRight implements Diagram{
	
	public int animationType;
	public char[][] board;

	public CombineLeftRight(Diagram left, Diagram right, int animationType) {
		if (left.getNumberRows() != right.getNumberRows()) {
			throw new IllegalArgumentException(
					"The number of diagrams in the" + "left and right diagrams are different");
		}

		this.animationType = animationType;
		this.board = TwoDimArrayUtil.appendLeftRight(left.getBoard(), right.getBoard());

	}

	public char[][] getBoard() {
		return board;
	}

	public char[][] nextAnimationStep() {
		if (animationType == 1) {
			TwoDimArrayUtil.rotateLeftOneColumn(board);
		}
		if (animationType == 2) {
			TwoDimArrayUtil.rotateLeftOneColumn(board);
		}
		return board;
	}

	public int getNumberRows() {
		int rows = board.length;
		return rows;
	}

	public int getNumberCols() {
		int cols = board[0].length;
		return cols;
	}
}
