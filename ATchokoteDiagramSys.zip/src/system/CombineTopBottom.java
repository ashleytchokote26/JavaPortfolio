package system;

public class CombineTopBottom implements Diagram {
	
	public int animationType;
	public char[][] board;
	
	public CombineTopBottom(Diagram top, Diagram bottom, int animationType) {
		if(top.getNumberCols() != bottom.getNumberCols()) {
			throw new IllegalArgumentException("The number of colums are different "
					+ "for the top and bottom diagram");
		}
		this.animationType = animationType;
		this.board = TwoDimArrayUtil.appendTopBottom(top.getBoard(), bottom.getBoard());
	}
	
	public char[][] getBoard(){
		return board;
	}
	
	public char[][] nextAnimationStep(){
		if (animationType == 1) {
			TwoDimArrayUtil.rotateLeftOneColumn(board);
		}
		if(animationType == 2) {
			TwoDimArrayUtil.rotateTopOneRow(board);
		}
		return board;
	}
	
	public int getNumberRows() {
		int rows = board.length;
		return rows;
	}
	
	public int getNumberCols() {
		int cols = board[0].length;
		return cols;
	}

}
