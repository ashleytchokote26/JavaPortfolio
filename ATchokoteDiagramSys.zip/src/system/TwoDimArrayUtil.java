package system;

public class TwoDimArrayUtil {

	public TwoDimArrayUtil() {

	}

	public static boolean isRagged(char[][] array) {
		if (array == null) {
			throw new IllegalArgumentException("Array has no contents.");
		}
		int arrayRows = array.length;
		for (int i = 1; i < arrayRows; i++) {
			if (array[i - 1].length != array[i].length) {
				return true;
			}
		}
		return false;

	}

	public static void rotateTopOneRow(char[][] array) {
		// check if array has contents.
		if (array == null) {
			throw new IllegalArgumentException("Array has no contents.");
		}
		// check if array is ragged.
		if (isRagged(array)) {
			throw new IllegalArgumentException("Array is ragged.");
		}
		// check if the array has one row
		if (array.length <= 1) {
			return;
		}

		char[] answer = new char[array[0].length];
		answer = array[0];
		for (int row = 1; row < array.length; row++) {
			array[row - 1] = array[row];
		}
		array[array.length - 1] = answer;
	}

	public static void rotateLeftOneColumn(char[][] array) {
		if (array == null) {
			throw new IllegalArgumentException("Array has no contents.");
		}
		if (isRagged(array)) {
			throw new IllegalArgumentException("Array is ragged.");
		}

		if (array[0].length <= 1) {
			return;
		}
		if (array[0].length > 1) {
			for (int row = 0; row < array.length; row++) {
				for (int col = 0; col < array[row].length - 1; col++) {
					char answer = array[row][col];
					array[row][col] = array[row][col + 1];
					array[row][col + 1] = answer;
				}
			}
		}
	}

	public static char[][] appendTopBottom(char[][] top, char[][] bottom) {
		// initialize the total array rows
		int arrayRow = top.length + bottom.length;
		// initialize the array with the answer.
		char[][] answer = new char[arrayRow][];

		for (int row = 0; row < top.length; row++) {
			// values of the answer array = top array values
			answer[row] = top[row];
		}
		for (int row = 0; row < bottom.length; row++) {
			answer[row + top.length] = bottom[row];
		}
		return answer;
	}

	public static char[][] appendLeftRight(char[][] left, char[][] right) {

		char[][] answer = new char[Math.max(left.length, right.length)][];
		for (int row = 0; row < answer.length; row++) {
			int len = 0;
			
			if (row < left.length) {
				len = left[row].length;
			}
			if (row < right.length) {
				len = len + right[row].length;
			}
			
			answer[row] = new char[len];
			int answerCol = 0;
			if (row < left.length) {
				for (int col = 0; col < left[row].length; col++) {
					answer[row][answerCol] = left[row][col];
					answerCol++;
				}
			}
			if (row < right.length) {
				for (int col = 0; col < right[row].length; col++) {
					answer[row][answerCol] = right[row][col];
					answerCol++;
				}
			}

		}
		return answer;
	}
}