package app;

import java.util.Random;

public class DrawingApp {

	public static String getRectangle(int maxRows, int maxCols, char symbol) {
		String answer = "";

		for (int row = 1; row <= maxRows; row++) {
			for (int col = 1; col <= maxCols; col++) {
				answer += symbol;
			}
			answer += "\n";
		}

		if (maxRows < 1 || maxCols < 1) {
			return null;
		}
		answer = answer.trim();
		return answer;

	}

	public static String getFlag(int size, char color1, char color2, char color3) {
		String answer = "";
		if (size < 3) {
			return null;
		}
		for (int row = 1; row <= size; row++) {

			for (int col = 1; col <= row; col++) {
				answer += color1;

			}
			for (int row1 = 1; row1 <= (size * 5) - row; row1++) {
				if (row == 1 || row == size) {
					answer += color2;
				} else {
					answer += color3;

				}

			}
			answer += "\n";
		}
		for (int row = size; row >= 1; row--) {

			for (int col = 1; col <= row; col++) {
				answer += color1;
			}

			for (int col = 1; col <= (size * 5) - row; col++) {
				if (row == 1 || row == size) {
					answer += color2;
				} else {
					answer += color3;

				}

			}
			answer += "\n";
		}
		answer = answer.trim();
		return answer;
	}

	public static void main(String[] args) {
		System.out.println(getFlag(10, 'R', '.', 'Y'));
	}

	public static String getHorizontalBars(int maxRows, int maxCols, int bars,
			char color1, char color2, char color3) {
		String answer = "";
		int size = maxRows / bars;
		int num = 0;
		if (isValidColor(color1) && isValidColor(color2) && isValidColor(color3)) {
			for (int row = 0; row < maxRows; row = row + size) {
				if (num < bars) {
					if (num % 3 == 0) {
						answer += DrawingApp.getRectangle(size, maxCols, color1);
						num++;
					} else if (num % 3 == 1) {
						answer += DrawingApp.getRectangle(size, maxCols, color2);
						num++;
					} else if (num % 3 == 2) {
						answer += DrawingApp.getRectangle(size, maxCols, color3);
						num++;
					}
					answer += "\n";
				}
			}
		}
		answer = answer.trim();
		return answer;
	}

	public static String getVerticalBars(int maxRows, int maxCols, int bars,
			char color1, char color2, char color3) {
		String answer = "";
		int size = maxCols / bars;
		if(size < 1 || color1 == ' '|| color2 == ' ' || color3 == ' ') {
			return null;
		}
		if (isValidColor(color1) && isValidColor(color2) && isValidColor(color3)) {
			for (int row = 1; row <= maxRows; row = row + 1) {
				int base = 0;
				for (int col = 1; col <= size * bars; col = col + size) {
					if (base % 3 == 0) {
						answer += DrawingApp.getRectangle(1, size, color1);
						base++;
					} else if (base % 3 == 1) {
						answer += DrawingApp.getRectangle(1, size, color2);
						base++;
					} else if (base % 3 == 2) {
						answer += DrawingApp.getRectangle(1, size, color3);
						base++;
					}
				}
				answer += "\n";
			}
		}
		answer = answer.trim();
		return answer;

	}

	public static char getRandomColor(Random random) {
		int random1 = random.nextInt(6);
		char symbol = ' ';
		if (random1 == 0) {
			symbol = 'R';
		}
		if (random1 == 1) {
			symbol = 'G';
		}
		if (random1 == 2) {
			symbol = 'B';
		}
		if (random1 == 3) {
			symbol = 'Y';
		}
		if (random1 == 4) {
			symbol = '*';
		}
		if (random1 == 5) {
			symbol = '.';
		}
		return symbol;
	}

	private static boolean isValidColor(char color) {
		if (color == 'R' || color == 'G' || color == 'B' || color == 'Y' || 
				color == '*' || color == '.') {
			return true;
		} else {
			return false;
		}

	}
}