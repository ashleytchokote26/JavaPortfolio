package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import system.TwoDimArrayUtil;

public class StudentTests {

	@Test
	public void student01Ragged() {
		boolean answer = false;
		char[][] array = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		boolean ragged = TwoDimArrayUtil.isRagged(array);
		assertEquals(ragged, answer);
	}

	@Test
	public void student02Ragged() {
		boolean answer = true;
		char[][] array = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9, 10 } };
		boolean ragged = TwoDimArrayUtil.isRagged(array);
		assertEquals(ragged, answer);
	}

	@Test
	public void student03RotateTopOne() {

		char[][] array = { { '1', '2', '3' }, { '4', '5', '6' }, { '7', '8', '9' } };
		char[][] rotatedArray = { { '4', '5', '6' }, { '7', '8', '9' }, { '1', '2', '3' } };
		TwoDimArrayUtil.rotateTopOneRow(array);
		String answer = getStringForArray(array);
		System.out.println(answer);
		String expectedResult = getStringForArray(rotatedArray);
		System.out.println(expectedResult);
		assertTrue(answer.equals(expectedResult));
	}

	@Test
	public void student04rotateLeftOneColumn() {
		char[][] array = { { '1', '2', '3' }, { '4', '5', '6' }, { '7', '8', '9' } };
		char[][] rotatedArray = { { '2', '3', '1' }, { '5', '6', '4' }, { '8', '9', '7' } };
		TwoDimArrayUtil.rotateLeftOneColumn(array);
		String answer = getStringForArray(array);
		System.out.println(answer);
		String expectedResult = getStringForArray(rotatedArray);
		System.out.println(expectedResult);
		assertTrue(answer.equals(expectedResult));

	}

	@Test
	public void student05AppendLeftRight() {
		char[][] leftArray = { { '1', '2', '3' }, { '4', '5', '6' }, { '7', '8', '9' } };
		char[][] rightArray = { { 'a', 'b', 'c' }, { 'd', 'e', 'f' }, { 'g', 'h', 'i' } };
		char[][] combinedArray = { { '1', '2', '3', 'a', 'b', 'c' }, { '4', '5', '6', 'd', 'e', 'f' },
				{ '7', '8', '9', 'g', 'h', 'i' } };
		char[][] answer = TwoDimArrayUtil.appendLeftRight(leftArray, rightArray);
		String answer1 = getStringForArray(answer);
		System.out.println(answer1);
		String expectedResult = getStringForArray(combinedArray);
		System.out.println(expectedResult);
		assertTrue(answer1.equals(expectedResult));
	}
	


	private static String getStringForArray(char[][] array) {
		String answer = "";
		for (int row = 0; row < array.length; row++) {
			for (int j = 0; j < array[row].length; j++) {
				answer += array[row][j];
			}
		}
		return answer;

	}
}
