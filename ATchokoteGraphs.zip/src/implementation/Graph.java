package implementation;

import java.util.*;

import javax.security.auth.callback.Callback;

/**
 * Implements a graph. We use two maps: one map for adjacency properties
 * (adjancencyMap) and one map (dataMap) to keep track of the data associated
 * with a vertex.
 * 
 * @author cmsc132
 * 
 * @param <E>
 */

class compareCost implements Comparator<String> {
	protected HashMap<String, Integer> costTree;

	public compareCost(HashMap<String, Integer> cost) {
		this.costTree = cost;
	}

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		return costTree.get(o1).compareTo(costTree.get(o2));
	}

}

public class Graph<E> {
	/* You must use the following maps in your implementation */
	private HashMap<String, HashMap<String, Integer>> adjacencyMap;
	private HashMap<String, E> dataMap;

	public Graph() {
		this.adjacencyMap = new HashMap<String, HashMap<String, Integer>>();
		this.dataMap = new HashMap<String, E>();
	}

	public void addVertex(String vertexName, E data) {
		if (adjacencyMap.containsKey(vertexName)) {
			throw new IllegalArgumentException("Vertex already exists");
		} else {
			dataMap.put(vertexName, data);
			adjacencyMap.put(vertexName, new HashMap<String, Integer>());
		}

	}

	public void addDirectedEdge(String startVertexName, String endVertexName, int cost) {
		if (!adjacencyMap.containsKey(endVertexName) || !adjacencyMap.containsKey(startVertexName)) {
			throw new IllegalArgumentException("One of the vertices are not part of the graph.");
		} else {
			adjacencyMap.get(startVertexName).put(endVertexName, cost);
		}
	}

	public String toString() {
		TreeSet<String> vertex = new TreeSet<>();
		TreeSet<String> vertices = new TreeSet<>();
		String answer = "";

		vertex.addAll(dataMap.keySet());
		for (String string : adjacencyMap.keySet()) {
			vertices.add("Vertex" + "(" + string + ")" + "--->" + adjacencyMap.get(string) + "\n");
		}
		answer += "Vertices: " + vertex + "\n" + "Edges: " + "\n";
		for (String string : vertices) {
			answer += string;
		}
		return answer;
	}

	public Map<String, Integer> getAdjacentVertices(String vertexName) {
		return adjacencyMap.get(vertexName);
	}

	public int getCost(String startVertexName, String endVertexName) {
		return adjacencyMap.get(startVertexName).get(endVertexName);
	}

	public Set<String> getVertices() {
		return dataMap.keySet();
	}

	public E getData(String vertex) {
		if (!dataMap.containsKey(vertex)) {
			throw new IllegalArgumentException("One of the vertices are not part of the graph.");
		}
		return dataMap.get(vertex);
	}

	public void doDepthFirstSearch(String startVertexName, CallBack<E> callback) {
		if (!adjacencyMap.containsKey(startVertexName)) {
			throw new IllegalArgumentException("One of the vertices are not part of the graph.");
		}

		Stack<String> stack = new Stack<>();
		stack.push(startVertexName);
		PriorityQueue<String> visitedNodes = new PriorityQueue<>();
		while (!stack.isEmpty()) {
			String current = stack.pop();
			if (!visitedNodes.contains(current)) {
				callback.processVertex(current, dataMap.get(current));
				for (String str : adjacencyMap.get(current).keySet()) {
					stack.push(str);
				}
				visitedNodes.offer(current);
			}

		}

	}

	public void doBreadthFirstSearch(String startVertexName, CallBack<E> callback) {
		if (!adjacencyMap.containsKey(startVertexName)) {
			throw new IllegalArgumentException("One of the vertices are not part of the graph.");
		}
		Stack<String> stack = new Stack<>();
		PriorityQueue<String> visitedNodes = new PriorityQueue<>();

		visitedNodes.offer(startVertexName);
		while (!visitedNodes.isEmpty()) {
			String current = visitedNodes.poll();
			if (!stack.contains(current)) {
				callback.processVertex(current, dataMap.get(current));

				visitedNodes.addAll(adjacencyMap.get(current).keySet());
				stack.add(current);
			}
		}
	}

	public int doDijkstras(String startVertexName, String endVertexName, ArrayList<String> shortestPath) {
		if (!adjacencyMap.containsKey(startVertexName)) {
			throw new IllegalArgumentException("One of the vertices are not part of the graph.");
		}

		HashMap<String, String> pre = new HashMap<>();
		HashSet<String> visitedNodes = new HashSet<>();
		HashMap<String, Integer> cost = new HashMap<>();
		HashMap<String, Integer> minCost;
		String vCost;
		for (String s : getVertices()) {
			if (!s.equals(startVertexName)) {
				cost.put(s, -1);
			} else {
				cost.put(s, 0);
			}
			pre.put(s, "None");
		}
		Comparator<String> compare = new compareCost(cost);
		PriorityQueue<String> priorityQueue = new PriorityQueue<>(compare);
		priorityQueue.offer(startVertexName);
		while (!priorityQueue.isEmpty() && !visitedNodes.contains(endVertexName)) {
			vCost = "None";
			vCost = priorityQueue.poll();

			if (vCost.equals("None")) {
				break;
			}

			visitedNodes.add(vCost);
			minCost = adjacencyMap.get(vCost);
			if (minCost == null) {
				continue;
			}

			for (String s : minCost.keySet()) {
				int costs = cost.get(s);
				int lowCost = getCost(vCost, s);
				int newCost = lowCost + cost.get(vCost);
				if (costs > newCost || costs == -1) {
					cost.put(s, newCost);
					pre.put(s, vCost);
					if (priorityQueue.contains(s)) {
						priorityQueue.remove(s);

					} 
						priorityQueue.add(s);
					
				}
			}

		}
		Stack<String> stack = new Stack<>();
		if (cost.get(endVertexName) == -1) {
			shortestPath.add("None");
			return -1;
		}
		stack.push(endVertexName);
		String vertex = endVertexName;
		while (!pre.get(vertex).equals("None")) {
			vertex = pre.get(vertex);
			stack.push(vertex);
		}
		while (!stack.isEmpty()) {
			shortestPath.add(stack.pop());
		}
		return cost.get(endVertexName);
		// ArrayList<String> fullSet = new ArrayList<String>();
//		ArrayList<String> pre = new ArrayList<String>();
//		ArrayList<Integer> lowCost = new ArrayList<>();
//		ArrayList<String> vertices = new ArrayList<>();
//
//		pre.add(null);
//		lowCost.add(Integer.MAX_VALUE);
//
//		lowCost.set(0, 0);
//		int minimumCost = Integer.MAX_VALUE;
//		int indexVertex = Integer.MAX_VALUE;
//		while (fullSet.size() != vertices.size()) {
//			for (int i = 0; i < lowCost.size(); i++) {
//				if (lowCost.get(i) < minimumCost && (fullSet.contains(vertices.get(i)))) {
//					minimumCost = lowCost.get(i);
//					indexVertex = i;
//				}
//			}
//			String vertex = vertices.get(indexVertex);
//			fullSet.add(vertex);
//			for (String s : adjacencyMap.get(vertex).keySet()) {
//				if (!fullSet.contains(s)) {
//					int index = vertices.indexOf(s);
//					if (lowCost.get(index) > minimumCost + getCost(vertex, s)) {
//						lowCost.set(index, minimumCost + getCost(vertex, s));
//						pre.set(index, vertex);
//					}
//				}
//			}
//		

	}
}
